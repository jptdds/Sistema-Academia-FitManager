# Planejamento da Estrutura do Sistema de Gerenciamento para Academia

## Arquitetura do Sistema

O sistema será desenvolvido como uma aplicação de página única (SPA - Single Page Application) utilizando apenas HTML, CSS e JavaScript puro, sem frameworks. A arquitetura será baseada em componentes modulares para facilitar a manutenção e expansão.

## Estrutura de Arquivos e Diretórios

```
sistema_academia/
│
├── index.html                  # Página principal e ponto de entrada
├── css/
│   ├── style.css               # Estilos globais
│   ├── components.css          # Estilos de componentes reutilizáveis
│   ├── dashboard.css           # Estilos específicos para o dashboard
│   ├── alunos.css              # Estilos para gestão de alunos
│   ├── planos.css              # Estilos para gestão de planos
│   ├── pagamentos.css          # Estilos para controle de pagamentos
│   └── presenca.css            # Estilos para controle de presença
│
├── js/
│   ├── app.js                  # Inicialização e configuração da aplicação
│   ├── router.js               # Gerenciamento de rotas/navegação
│   ├── auth.js                 # Autenticação e controle de acesso
│   ├── storage.js              # Gerenciamento de dados (localStorage)
│   ├── utils.js                # Funções utilitárias
│   │
│   ├── components/             # Componentes reutilizáveis
│   │   ├── sidebar.js          # Barra lateral de navegação
│   │   ├── header.js           # Cabeçalho da aplicação
│   │   ├── modal.js            # Janelas modais
│   │   ├── table.js            # Tabelas de dados
│   │   ├── form.js             # Formulários
│   │   └── alerts.js           # Sistema de notificações
│   │
│   ├── modules/                # Módulos funcionais
│   │   ├── dashboard.js        # Funcionalidades do dashboard
│   │   ├── alunos.js           # Gestão de alunos
│   │   ├── planos.js           # Gestão de planos
│   │   ├── pagamentos.js       # Controle de pagamentos
│   │   ├── presenca.js         # Controle de presença
│   │   └── relatorios.js       # Geração de relatórios
│   │
│   └── models/                 # Modelos de dados
│       ├── aluno.js            # Modelo de dados de aluno
│       ├── plano.js            # Modelo de dados de plano
│       ├── pagamento.js        # Modelo de dados de pagamento
│       └── presenca.js         # Modelo de dados de presença
│
├── assets/
│   ├── img/                    # Imagens e ícones
│   └── fonts/                  # Fontes personalizadas
│
└── templates/                  # Templates HTML para as diferentes seções
    ├── login.html              # Tela de login
    ├── dashboard.html          # Dashboard principal
    ├── alunos.html             # Gestão de alunos
    ├── planos.html             # Gestão de planos
    ├── pagamentos.html         # Controle de pagamentos
    ├── presenca.html           # Controle de presença
    └── relatorios.html         # Relatórios
```

## Fluxo de Navegação

1. **Login**
   - Autenticação de usuário
   - Redirecionamento para Dashboard após login bem-sucedido

2. **Dashboard**
   - Visão geral com métricas principais
   - Acesso rápido às principais funcionalidades
   - Alertas de pagamentos em atraso e planos a vencer

3. **Gestão de Alunos**
   - Listagem de alunos com filtros
   - Formulário de cadastro/edição
   - Visualização detalhada de aluno
   - Histórico de pagamentos e frequência

4. **Gestão de Planos**
   - Listagem de planos disponíveis
   - Criação/edição de planos
   - Associação de planos a alunos

5. **Controle de Pagamentos**
   - Registro de novos pagamentos
   - Visualização de histórico de pagamentos
   - Relatórios financeiros

6. **Controle de Presença**
   - Registro de entrada/saída
   - Visualização de histórico de frequência
   - Relatórios de assiduidade

7. **Relatórios**
   - Geração de relatórios personalizados
   - Exportação de dados

## Componentes Visuais e Estilo

### Paleta de Cores
- **Cor primária**: #3498db (Azul)
- **Cor secundária**: #2ecc71 (Verde)
- **Cor de destaque**: #e74c3c (Vermelho)
- **Cores neutras**: #f5f5f5, #e0e0e0, #9e9e9e, #212121
- **Cor de fundo**: #f9f9f9

### Tipografia
- **Fonte principal**: 'Roboto', sans-serif
- **Fonte de títulos**: 'Montserrat', sans-serif
- **Tamanhos**:
  - Título principal: 24px
  - Subtítulos: 18px
  - Texto normal: 14px
  - Texto pequeno: 12px

### Componentes UI
- **Botões**: Estilo flat com hover effects
- **Cards**: Sombras sutis para elevação
- **Tabelas**: Linhas alternadas para melhor legibilidade
- **Formulários**: Campos com validação visual
- **Modais**: Sobreposição com fundo escurecido

## Armazenamento de Dados

Como o sistema utilizará apenas tecnologias frontend, o armazenamento será feito utilizando localStorage do navegador. A estrutura de dados será:

```javascript
// Exemplo de estrutura de dados no localStorage
{
  "usuarios": [
    {
      "id": 1,
      "nome": "Admin",
      "email": "admin@academia.com",
      "senha": "senha_hash",
      "nivel": "admin"
    }
  ],
  "alunos": [
    {
      "id": 1,
      "nome": "João Silva",
      "cpf": "123.456.789-00",
      "dataNascimento": "1990-01-15",
      "telefone": "(11) 98765-4321",
      "email": "joao@email.com",
      "endereco": "Rua Exemplo, 123",
      "dataInscricao": "2023-01-10",
      "status": "ativo",
      "planoId": 2
    }
  ],
  "planos": [
    {
      "id": 1,
      "nome": "Mensal",
      "valor": 89.90,
      "duracao": 30 // dias
    },
    {
      "id": 2,
      "nome": "Trimestral",
      "valor": 249.90,
      "duracao": 90 // dias
    }
  ],
  "pagamentos": [
    {
      "id": 1,
      "alunoId": 1,
      "planoId": 2,
      "valor": 249.90,
      "dataPagamento": "2023-01-10",
      "dataVencimento": "2023-04-10",
      "formaPagamento": "cartão",
      "status": "pago"
    }
  ],
  "presencas": [
    {
      "id": 1,
      "alunoId": 1,
      "dataEntrada": "2023-01-15T08:30:00",
      "dataSaida": "2023-01-15T10:15:00"
    }
  ]
}
```

## Funcionalidades Principais

### Sistema de Autenticação
- Login com email e senha
- Armazenamento de sessão
- Controle de níveis de acesso

### Dashboard
- Widgets com contadores e gráficos
- Lista de alunos com pagamento em atraso
- Lista de planos a vencer nos próximos 7 dias
- Gráfico de frequência semanal

### Gestão de Alunos
- CRUD completo (Create, Read, Update, Delete)
- Busca e filtros avançados
- Visualização de histórico
- Associação com planos

### Gestão de Planos
- Cadastro de diferentes tipos de planos
- Definição de valores e duração
- Relatório de adesão por plano

### Controle de Pagamentos
- Registro de pagamentos
- Alertas de vencimento
- Relatórios financeiros
- Comprovantes

### Controle de Presença
- Check-in/Check-out de alunos
- Histórico de frequência
- Relatórios de assiduidade

## Considerações Técnicas

1. **Responsividade**
   - Design adaptável para desktop, tablet e mobile
   - Layout flexível com CSS Grid e Flexbox
   - Media queries para ajustes específicos

2. **Performance**
   - Carregamento sob demanda de módulos
   - Otimização de operações com localStorage
   - Minimização de reflows e repaints

3. **Usabilidade**
   - Feedback visual para ações
   - Validação de formulários em tempo real
   - Mensagens de erro claras
   - Confirmações para ações críticas

4. **Acessibilidade**
   - Contraste adequado
   - Textos alternativos para imagens
   - Navegação por teclado
   - Semântica HTML apropriada
