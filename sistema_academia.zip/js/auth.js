/**
 * Sistema de autenticação para o Sistema de Gerenciamento de Academia
 */

const Auth = {
    /**
     * Usuário atual logado
     */
    currentUser: null,
    
    /**
     * Inicializa o sistema de autenticação
     */
    init: function() {
        // Verifica se há um usuário logado na sessão
        const savedUser = sessionStorage.getItem('academia_current_user');
        if (savedUser) {
            this.currentUser = JSON.parse(savedUser);
        }
    },
    
    /**
     * Realiza login de usuário
     * @param {string} email - Email do usuário
     * @param {string} senha - Senha do usuário
     * @returns {boolean} Verdadeiro se o login foi bem-sucedido
     */
    login: function(email, senha) {
        const usuarios = Storage.getCollection('usuarios');
        const usuario = usuarios.find(u => u.email === email && u.senha === senha);
        
        if (usuario) {
            // Remove a senha antes de armazenar na sessão
            const { senha, ...userWithoutPassword } = usuario;
            this.currentUser = userWithoutPassword;
            sessionStorage.setItem('academia_current_user', JSON.stringify(userWithoutPassword));
            return true;
        }
        
        return false;
    },
    
    /**
     * Realiza logout do usuário atual
     */
    logout: function() {
        this.currentUser = null;
        sessionStorage.removeItem('academia_current_user');
    },
    
    /**
     * Verifica se há um usuário logado
     * @returns {boolean} Verdadeiro se há um usuário logado
     */
    isLoggedIn: function() {
        return this.currentUser !== null;
    },
    
    /**
     * Obtém o usuário atual logado
     * @returns {Object|null} Usuário atual ou null se não houver
     */
    getCurrentUser: function() {
        return this.currentUser;
    },
    
    /**
     * Verifica se o usuário atual tem determinado nível de acesso
     * @param {string} nivel - Nível de acesso requerido
     * @returns {boolean} Verdadeiro se o usuário tem o nível requerido
     */
    hasAccess: function(nivel) {
        if (!this.isLoggedIn()) return false;
        
        // Administrador tem acesso a tudo
        if (this.currentUser.nivel === 'admin') return true;
        
        // Verifica se o nível do usuário é o requerido
        return this.currentUser.nivel === nivel;
    }
};
