/**
 * Gerenciamento de armazenamento local para o Sistema de Gerenciamento de Academia
 */

const Storage = {
    /**
     * Inicializa o armazenamento com dados padrão se não existirem
     */
    init: function() {
        // Verifica se já existe algum dado no localStorage
        if (!localStorage.getItem('academia_data')) {
            // Cria estrutura inicial de dados
            const initialData = {
                usuarios: [
                    {
                        id: 1,
                        nome: 'Administrador',
                        email: 'admin@academia.com',
                        senha: 'admin123', // Em produção, usar hash
                        nivel: 'admin'
                    }
                ],
                alunos: [],
                planos: [
                    {
                        id: 1,
                        nome: 'Mensal',
                        valor: 89.90,
                        duracao: 30 // dias
                    },
                    {
                        id: 2,
                        nome: 'Trimestral',
                        valor: 249.90,
                        duracao: 90 // dias
                    },
                    {
                        id: 3,
                        nome: 'Semestral',
                        valor: 459.90,
                        duracao: 180 // dias
                    },
                    {
                        id: 4,
                        nome: 'Anual',
                        valor: 799.90,
                        duracao: 365 // dias
                    }
                ],
                pagamentos: [],
                presencas: []
            };
            
            // Salva no localStorage
            localStorage.setItem('academia_data', JSON.stringify(initialData));
        }
    },
    
    /**
     * Obtém todos os dados do armazenamento
     * @returns {Object} Todos os dados armazenados
     */
    getData: function() {
        return JSON.parse(localStorage.getItem('academia_data'));
    },
    
    /**
     * Salva todos os dados no armazenamento
     * @param {Object} data - Dados a serem salvos
     */
    saveData: function(data) {
        localStorage.setItem('academia_data', JSON.stringify(data));
    },
    
    /**
     * Obtém uma coleção específica de dados
     * @param {string} collection - Nome da coleção (alunos, planos, etc.)
     * @returns {Array} Coleção de dados
     */
    getCollection: function(collection) {
        const data = this.getData();
        return data[collection] || [];
    },
    
    /**
     * Salva uma coleção específica de dados
     * @param {string} collection - Nome da coleção (alunos, planos, etc.)
     * @param {Array} items - Itens da coleção
     */
    saveCollection: function(collection, items) {
        const data = this.getData();
        data[collection] = items;
        this.saveData(data);
    },
    
    /**
     * Obtém um item específico de uma coleção
     * @param {string} collection - Nome da coleção (alunos, planos, etc.)
     * @param {number|string} id - ID do item
     * @returns {Object|null} Item encontrado ou null
     */
    getItem: function(collection, id) {
        const items = this.getCollection(collection);
        return items.find(item => item.id == id) || null;
    },
    
    /**
     * Adiciona um item a uma coleção
     * @param {string} collection - Nome da coleção (alunos, planos, etc.)
     * @param {Object} item - Item a ser adicionado
     * @returns {Object} Item adicionado com ID gerado
     */
    addItem: function(collection, item) {
        const items = this.getCollection(collection);
        
        // Gera ID para o novo item
        const maxId = items.reduce((max, item) => Math.max(max, item.id || 0), 0);
        item.id = maxId + 1;
        
        // Adiciona o item à coleção
        items.push(item);
        this.saveCollection(collection, items);
        
        return item;
    },
    
    /**
     * Atualiza um item em uma coleção
     * @param {string} collection - Nome da coleção (alunos, planos, etc.)
     * @param {number|string} id - ID do item
     * @param {Object} updates - Atualizações a serem aplicadas
     * @returns {Object|null} Item atualizado ou null se não encontrado
     */
    updateItem: function(collection, id, updates) {
        const items = this.getCollection(collection);
        const index = items.findIndex(item => item.id == id);
        
        if (index === -1) return null;
        
        // Atualiza o item
        items[index] = { ...items[index], ...updates };
        this.saveCollection(collection, items);
        
        return items[index];
    },
    
    /**
     * Remove um item de uma coleção
     * @param {string} collection - Nome da coleção (alunos, planos, etc.)
     * @param {number|string} id - ID do item
     * @returns {boolean} Verdadeiro se o item foi removido
     */
    removeItem: function(collection, id) {
        const items = this.getCollection(collection);
        const filteredItems = items.filter(item => item.id != id);
        
        if (filteredItems.length === items.length) return false;
        
        this.saveCollection(collection, filteredItems);
        return true;
    },
    
    /**
     * Filtra itens em uma coleção
     * @param {string} collection - Nome da coleção (alunos, planos, etc.)
     * @param {Function} filterFn - Função de filtro
     * @returns {Array} Itens filtrados
     */
    filterItems: function(collection, filterFn) {
        const items = this.getCollection(collection);
        return items.filter(filterFn);
    },
    
    /**
     * Exporta todos os dados para um arquivo JSON
     * @returns {string} Dados em formato JSON
     */
    exportData: function() {
        return JSON.stringify(this.getData(), null, 2);
    },
    
    /**
     * Importa dados de um arquivo JSON
     * @param {string} jsonData - Dados em formato JSON
     * @returns {boolean} Verdadeiro se a importação foi bem-sucedida
     */
    importData: function(jsonData) {
        try {
            const data = JSON.parse(jsonData);
            
            // Verifica se o formato dos dados é válido
            if (!data.usuarios || !data.alunos || !data.planos || !data.pagamentos || !data.presencas) {
                return false;
            }
            
            this.saveData(data);
            return true;
        } catch (error) {
            console.error('Erro ao importar dados:', error);
            return false;
        }
    },
    
    /**
     * Limpa todos os dados do armazenamento
     */
    clearData: function() {
        localStorage.removeItem('academia_data');
        this.init();
    }
};
