/**
 * Utilitários para o Sistema de Gerenciamento de Academia
 */

const Utils = {
    /**
     * Gera um ID único
     * @returns {string} ID único
     */
    generateId: function() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
    },

    /**
     * Formata data para exibição
     * @param {string|Date} date - Data a ser formatada
     * @returns {string} Data formatada (DD/MM/YYYY)
     */
    formatDate: function(date) {
        if (!date) return '';
        const d = new Date(date);
        return d.toLocaleDateString('pt-BR');
    },

    /**
     * Formata data e hora para exibição
     * @param {string|Date} date - Data a ser formatada
     * @returns {string} Data e hora formatadas (DD/MM/YYYY HH:MM)
     */
    formatDateTime: function(date) {
        if (!date) return '';
        const d = new Date(date);
        return `${d.toLocaleDateString('pt-BR')} ${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`;
    },

    /**
     * Formata valor monetário para exibição
     * @param {number} value - Valor a ser formatado
     * @returns {string} Valor formatado (R$ X,XX)
     */
    formatCurrency: function(value) {
        return new Intl.NumberFormat('pt-BR', {
            style: 'currency',
            currency: 'BRL'
        }).format(value);
    },

    /**
     * Valida CPF
     * @param {string} cpf - CPF a ser validado
     * @returns {boolean} Verdadeiro se o CPF for válido
     */
    validateCPF: function(cpf) {
        cpf = cpf.replace(/[^\d]/g, '');
        
        if (cpf.length !== 11) return false;
        
        // Verifica se todos os dígitos são iguais
        if (/^(\d)\1+$/.test(cpf)) return false;
        
        // Validação do primeiro dígito verificador
        let sum = 0;
        for (let i = 0; i < 9; i++) {
            sum += parseInt(cpf.charAt(i)) * (10 - i);
        }
        let remainder = 11 - (sum % 11);
        let digit1 = remainder > 9 ? 0 : remainder;
        
        // Validação do segundo dígito verificador
        sum = 0;
        for (let i = 0; i < 10; i++) {
            sum += parseInt(cpf.charAt(i)) * (11 - i);
        }
        remainder = 11 - (sum % 11);
        let digit2 = remainder > 9 ? 0 : remainder;
        
        return digit1 === parseInt(cpf.charAt(9)) && digit2 === parseInt(cpf.charAt(10));
    },

    /**
     * Valida email
     * @param {string} email - Email a ser validado
     * @returns {boolean} Verdadeiro se o email for válido
     */
    validateEmail: function(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    },

    /**
     * Formata CPF para exibição
     * @param {string} cpf - CPF a ser formatado
     * @returns {string} CPF formatado (XXX.XXX.XXX-XX)
     */
    formatCPF: function(cpf) {
        cpf = cpf.replace(/[^\d]/g, '');
        return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
    },

    /**
     * Formata telefone para exibição
     * @param {string} phone - Telefone a ser formatado
     * @returns {string} Telefone formatado ((XX) XXXXX-XXXX)
     */
    formatPhone: function(phone) {
        phone = phone.replace(/[^\d]/g, '');
        if (phone.length === 11) {
            return phone.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
        }
        return phone.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
    },

    /**
     * Calcula a diferença em dias entre duas datas
     * @param {string|Date} date1 - Primeira data
     * @param {string|Date} date2 - Segunda data
     * @returns {number} Diferença em dias
     */
    daysBetween: function(date1, date2) {
        const d1 = new Date(date1);
        const d2 = new Date(date2);
        const diffTime = Math.abs(d2 - d1);
        return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    },

    /**
     * Verifica se uma data está no passado
     * @param {string|Date} date - Data a ser verificada
     * @returns {boolean} Verdadeiro se a data estiver no passado
     */
    isDateInPast: function(date) {
        const d = new Date(date);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        return d < today;
    },

    /**
     * Adiciona dias a uma data
     * @param {string|Date} date - Data base
     * @param {number} days - Número de dias a adicionar
     * @returns {Date} Nova data
     */
    addDays: function(date, days) {
        const d = new Date(date);
        d.setDate(d.getDate() + days);
        return d;
    },

    /**
     * Debounce para evitar múltiplas chamadas de função
     * @param {Function} func - Função a ser executada
     * @param {number} wait - Tempo de espera em ms
     * @returns {Function} Função com debounce
     */
    debounce: function(func, wait) {
        let timeout;
        return function(...args) {
            const context = this;
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(context, args), wait);
        };
    }
};
