/**
 * Sistema de roteamento para o Sistema de Gerenciamento de Academia
 */

const Router = {
    /**
     * Página atual
     */
    currentPage: 'dashboard',
    
    /**
     * Inicializa o sistema de roteamento
     */
    init: function() {
        // Verifica se há uma rota na URL
        const hash = window.location.hash.substring(1);
        if (hash) {
            this.navigateTo(hash);
        } else {
            // Se não houver rota, verifica se o usuário está logado
            if (!Auth.isLoggedIn()) {
                this.showLoginPage();
            } else {
                this.navigateTo('dashboard');
            }
        }
        
        // Adiciona listener para mudanças na hash da URL
        window.addEventListener('hashchange', () => {
            const hash = window.location.hash.substring(1);
            if (hash) {
                this.navigateTo(hash);
            }
        });
        
        // Adiciona listeners para os itens do menu
        document.querySelectorAll('.menu-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const page = item.getAttribute('data-page');
                this.navigateTo(page);
            });
        });
    },
    
    /**
     * Navega para uma página específica
     * @param {string} page - Nome da página
     */
    navigateTo: function(page) {
        // Verifica se o usuário está logado
        if (!Auth.isLoggedIn() && page !== 'login') {
            this.showLoginPage();
            return;
        }
        
        // Atualiza a página atual
        this.currentPage = page;
        
        // Atualiza a URL
        window.location.hash = page;
        
        // Atualiza o título da página
        document.querySelector('.page-title').textContent = this.getPageTitle(page);
        
        // Esconde todos os containers
        document.querySelectorAll('.content-area > div').forEach(container => {
            container.classList.add('hidden');
        });
        
        // Mostra o container da página atual
        const container = document.getElementById(`${page}-container`);
        if (container) {
            container.classList.remove('hidden');
        }
        
        // Atualiza o item ativo no menu
        document.querySelectorAll('.menu-item').forEach(item => {
            item.classList.remove('active');
            if (item.getAttribute('data-page') === page) {
                item.classList.add('active');
            }
        });
        
        // Carrega o conteúdo da página
        this.loadPageContent(page);
    },
    
    /**
     * Mostra a página de login
     */
    showLoginPage: function() {
        // Esconde a sidebar e o header
        document.getElementById('sidebar').classList.add('hidden');
        document.querySelector('.header').classList.add('hidden');
        
        // Esconde todos os containers
        document.querySelectorAll('.content-area > div').forEach(container => {
            container.classList.add('hidden');
        });
        
        // Mostra o container de login
        const loginContainer = document.getElementById('login-container');
        loginContainer.classList.remove('hidden');
        
        // Carrega o conteúdo da página de login
        this.loadLoginPage();
    },
    
    /**
     * Carrega o conteúdo da página de login
     */
    loadLoginPage: function() {
        const loginContainer = document.getElementById('login-container');
        
        loginContainer.innerHTML = `
            <div class="login-wrapper">
                <div class="login-card">
                    <div class="login-header">
                        <h1 class="logo">FitManager</h1>
                        <p>Sistema de Gerenciamento para Academia</p>
                    </div>
                    <div class="login-body">
                        <form id="login-form">
                            <div class="form-group">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" id="email" class="form-control" placeholder="Seu email" required>
                            </div>
                            <div class="form-group">
                                <label for="senha" class="form-label">Senha</label>
                                <input type="password" id="senha" class="form-control" placeholder="Sua senha" required>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-block">Entrar</button>
                            </div>
                        </form>
                        <div id="login-error" class="form-error hidden">Email ou senha incorretos.</div>
                    </div>
                    <div class="login-footer">
                        <p>© ${new Date().getFullYear()} FitManager - Todos os direitos reservados</p>
                    </div>
                </div>
            </div>
        `;
        
        // Adiciona listener para o formulário de login
        document.getElementById('login-form').addEventListener('submit', (e) => {
            e.preventDefault();
            
            const email = document.getElementById('email').value;
            const senha = document.getElementById('senha').value;
            
            if (Auth.login(email, senha)) {
                // Mostra a sidebar e o header
                document.getElementById('sidebar').classList.remove('hidden');
                document.querySelector('.header').classList.remove('hidden');
                
                // Navega para o dashboard
                this.navigateTo('dashboard');
            } else {
                // Mostra mensagem de erro
                document.getElementById('login-error').classList.remove('hidden');
            }
        });
    },
    
    /**
     * Carrega o conteúdo de uma página específica
     * @param {string} page - Nome da página
     */
    loadPageContent: function(page) {
        switch (page) {
            case 'dashboard':
                DashboardModule.init();
                break;
            case 'alunos':
                AlunosModule.init();
                break;
            case 'planos':
                PlanosModule.init();
                break;
            case 'pagamentos':
                PagamentosModule.init();
                break;
            case 'presenca':
                PresencaModule.init();
                break;
            case 'relatorios':
                RelatoriosModule.init();
                break;
        }
    },
    
    /**
     * Obtém o título de uma página específica
     * @param {string} page - Nome da página
     * @returns {string} Título da página
     */
    getPageTitle: function(page) {
        switch (page) {
            case 'dashboard':
                return 'Dashboard';
            case 'alunos':
                return 'Gestão de Alunos';
            case 'planos':
                return 'Gestão de Planos';
            case 'pagamentos':
                return 'Controle de Pagamentos';
            case 'presenca':
                return 'Controle de Presença';
            case 'relatorios':
                return 'Relatórios';
            default:
                return 'Dashboard';
        }
    }
};
