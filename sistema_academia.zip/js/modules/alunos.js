/**
 * Módulo de Alunos para o Sistema de Gerenciamento de Academia
 */

const AlunosModule = {
    /**
     * Inicializa o módulo de alunos
     */
    init: function() {
        console.log('Inicializando módulo de Alunos...');
        
        // Obtém o container de alunos
        const container = document.getElementById('alunos-container');
        
        // Carrega o conteúdo da página de alunos
        this.loadAlunosPage(container);
        
        console.log('Módulo de Alunos inicializado com sucesso!');
    },
    
    /**
     * Carrega o conteúdo da página de alunos
     * @param {HTMLElement} container - Container da página
     */
    loadAlunosPage: function(container) {
        // Constrói o HTML da página
        container.innerHTML = `
            <div class="page-actions">
                <button id="novo-aluno-btn" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Novo Aluno
                </button>
            </div>
            
            <div class="filters">
                <div class="filters-header">
                    <h3 class="filters-title">Filtros</h3>
                    <button class="filters-toggle">
                        Mostrar filtros <i class="fas fa-chevron-down"></i>
                    </button>
                </div>
                <div class="filters-body">
                    <div class="form-group">
                        <label for="filtro-nome" class="form-label">Nome</label>
                        <input type="text" id="filtro-nome" class="form-control" placeholder="Buscar por nome">
                    </div>
                    <div class="form-group">
                        <label for="filtro-status" class="form-label">Status</label>
                        <select id="filtro-status" class="form-control">
                            <option value="">Todos</option>
                            <option value="ativo">Ativo</option>
                            <option value="inativo">Inativo</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="filtro-plano" class="form-label">Plano</label>
                        <select id="filtro-plano" class="form-control">
                            <option value="">Todos</option>
                            <!-- Opções de planos serão adicionadas dinamicamente -->
                        </select>
                    </div>
                </div>
                <div class="filters-footer">
                    <button id="limpar-filtros-btn" class="btn btn-secondary">Limpar</button>
                    <button id="aplicar-filtros-btn" class="btn btn-primary">Aplicar</button>
                </div>
            </div>
            
            <div class="table-container">
                <table class="table" id="alunos-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>CPF</th>
                            <th>Telefone</th>
                            <th>Plano</th>
                            <th>Vencimento</th>
                            <th>Status</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Dados dos alunos serão adicionados dinamicamente -->
                    </tbody>
                </table>
            </div>
            
            <div class="pagination" id="alunos-pagination">
                <!-- Paginação será adicionada dinamicamente -->
            </div>
        `;
        
        // Carrega os dados dos alunos
        this.loadAlunosData();
        
        // Adiciona listeners para os botões
        document.getElementById('novo-aluno-btn').addEventListener('click', () => {
            this.showAlunoForm();
        });
        
        document.getElementById('aplicar-filtros-btn').addEventListener('click', () => {
            this.loadAlunosData();
        });
        
        document.getElementById('limpar-filtros-btn').addEventListener('click', () => {
            document.getElementById('filtro-nome').value = '';
            document.getElementById('filtro-status').value = '';
            document.getElementById('filtro-plano').value = '';
            this.loadAlunosData();
        });
        
        // Carrega as opções de planos
        this.loadPlanoOptions();
        
        // Adiciona listener para o toggle de filtros
        const filtersToggle = document.querySelector('.filters-toggle');
        const filtersBody = document.querySelector('.filters-body');
        const filtersFooter = document.querySelector('.filters-footer');
        
        filtersToggle.addEventListener('click', () => {
            filtersBody.classList.toggle('hidden');
            filtersFooter.classList.toggle('hidden');
            filtersToggle.classList.toggle('collapsed');
        });
        
        // Inicialmente esconde os filtros em dispositivos móveis
        if (window.innerWidth <= 768) {
            filtersBody.classList.add('hidden');
            filtersFooter.classList.add('hidden');
            filtersToggle.classList.add('collapsed');
        }
    },
    
    /**
     * Carrega os dados dos alunos na tabela
     */
    loadAlunosData: function() {
        // Obtém os alunos do armazenamento
        let alunos = Storage.getCollection('alunos');
        
        // Aplica filtros
        const filtroNome = document.getElementById('filtro-nome').value.toLowerCase();
        const filtroStatus = document.getElementById('filtro-status').value;
        const filtroPlano = document.getElementById('filtro-plano').value;
        
        if (filtroNome) {
            alunos = alunos.filter(aluno => 
                aluno.nome.toLowerCase().includes(filtroNome)
            );
        }
        
        if (filtroStatus) {
            alunos = alunos.filter(aluno => aluno.status === filtroStatus);
        }
        
        if (filtroPlano) {
            alunos = alunos.filter(aluno => aluno.planoId == filtroPlano);
        }
        
        // Obtém a tabela
        const tbody = document.querySelector('#alunos-table tbody');
        
        // Limpa a tabela
        tbody.innerHTML = '';
        
        // Se não houver alunos, mostra mensagem
        if (alunos.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="8" class="text-center">
                        <div class="empty-state">
                            <i class="fas fa-users empty-state-icon"></i>
                            <h4 class="empty-state-title">Nenhum aluno encontrado</h4>
                            <p class="empty-state-text">Cadastre novos alunos ou ajuste os filtros de busca.</p>
                            <button class="btn btn-primary" id="empty-novo-aluno-btn">
                                <i class="fas fa-plus"></i> Novo Aluno
                            </button>
                        </div>
                    </td>
                </tr>
            `;
            
            document.getElementById('empty-novo-aluno-btn').addEventListener('click', () => {
                this.showAlunoForm();
            });
            
            return;
        }
        
        // Preenche a tabela com os dados dos alunos
        alunos.forEach(aluno => {
            // Obtém o plano do aluno
            const plano = Storage.getItem('planos', aluno.planoId);
            
            // Obtém o último pagamento do aluno
            const pagamentos = Storage.getCollection('pagamentos')
                .filter(p => p.alunoId == aluno.id)
                .sort((a, b) => new Date(b.dataPagamento) - new Date(a.dataPagamento));
            
            const ultimoPagamento = pagamentos.length > 0 ? pagamentos[0] : null;
            
            // Cria a linha da tabela
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${aluno.id}</td>
                <td>${aluno.nome}</td>
                <td>${Utils.formatCPF(aluno.cpf)}</td>
                <td>${Utils.formatPhone(aluno.telefone)}</td>
                <td>${plano ? plano.nome : 'N/A'}</td>
                <td>${ultimoPagamento ? Utils.formatDate(ultimoPagamento.dataVencimento) : 'N/A'}</td>
                <td>
                    <span class="status ${aluno.status}">
                        ${aluno.status === 'ativo' ? 'Ativo' : 'Inativo'}
                    </span>
                </td>
                <td class="actions">
                    <button class="btn-icon view" data-id="${aluno.id}" title="Visualizar">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn-icon edit" data-id="${aluno.id}" title="Editar">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn-icon delete" data-id="${aluno.id}" title="Excluir">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;
            
            // Adiciona a linha à tabela
            tbody.appendChild(tr);
            
            // Adiciona listeners para os botões de ação
            tr.querySelector('.btn-icon.view').addEventListener('click', () => {
                this.viewAluno(aluno.id);
            });
            
            tr.querySelector('.btn-icon.edit').addEventListener('click', () => {
                this.editAluno(aluno.id);
            });
            
            tr.querySelector('.btn-icon.delete').addEventListener('click', () => {
                this.deleteAluno(aluno.id);
            });
        });
    },
    
    /**
     * Carrega as opções de planos no filtro
     */
    loadPlanoOptions: function() {
        // Obtém os planos do armazenamento
        const planos = Storage.getCollection('planos');
        
        // Obtém o select de planos
        const select = document.getElementById('filtro-plano');
        
        // Adiciona as opções de planos
        planos.forEach(plano => {
            const option = document.createElement('option');
            option.value = plano.id;
            option.textContent = plano.nome;
            select.appendChild(option);
        });
    },
    
    /**
     * Mostra o formulário de cadastro/edição de aluno
     * @param {Object} aluno - Dados do aluno para edição (null para novo aluno)
     */
    showAlunoForm: function(aluno = null) {
        // Define o título do modal
        const title = aluno ? 'Editar Aluno' : 'Novo Aluno';
        
        // Obtém os planos para o select
        const planos = Storage.getCollection('planos');
        let planosOptions = '<option value="">Selecione um plano</option>';
        
        planos.forEach(plano => {
            const selected = aluno && aluno.planoId == plano.id ? 'selected' : '';
            planosOptions += `<option value="${plano.id}" ${selected}>${plano.nome} - ${Utils.formatCurrency(plano.valor)}</option>`;
        });
        
        // Constrói o conteúdo do modal
        const content = `
            <form id="aluno-form">
                <div class="form-row">
                    <div class="form-group">
                        <label for="nome" class="form-label">Nome Completo</label>
                        <input type="text" id="nome" class="form-control" value="${aluno ? aluno.nome : ''}" required>
                    </div>
                    <div class="form-group">
                        <label for="cpf" class="form-label">CPF</label>
                        <input type="text" id="cpf" class="form-control" value="${aluno ? aluno.cpf : ''}" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="data-nascimento" class="form-label">Data de Nascimento</label>
                        <input type="date" id="data-nascimento" class="form-control" value="${aluno ? aluno.dataNascimento : ''}" required>
                    </div>
                    <div class="form-group">
                        <label for="telefone" class="form-label">Telefone</label>
                        <input type="text" id="telefone" class="form-control" value="${aluno ? aluno.telefone : ''}" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" id="email" class="form-control" value="${aluno ? aluno.email : ''}" required>
                </div>
                
                <div class="form-group">
                    <label for="endereco" class="form-label">Endereço</label>
                    <input type="text" id="endereco" class="form-control" value="${aluno ? aluno.endereco : ''}" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="plano" class="form-label">Plano</label>
                        <select id="plano" class="form-control" required>
                            ${planosOptions}
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="status" class="form-label">Status</label>
                        <select id="status" class="form-control" required>
                            <option value="ativo" ${aluno && aluno.status === 'ativo' ? 'selected' : ''}>Ativo</option>
                            <option value="inativo" ${aluno && aluno.status === 'inativo' ? 'selected' : ''}>Inativo</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="observacoes" class="form-label">Observações</label>
                    <textarea id="observacoes" class="form-control" rows="3">${aluno ? aluno.observacoes || '' : ''}</textarea>
                </div>
            </form>
        `;
        
        // Abre o modal
        ModalComponent.open({
            title: title,
            content: content,
            confirmText: 'Salvar',
            cancelText: 'Cancelar',
            onConfirm: () => {
                this.saveAluno(aluno ? aluno.id : null);
            }
        });
        
        // Adiciona máscaras e validações aos campos
        const cpfInput = document.getElementById('cpf');
        cpfInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 11) value = value.slice(0, 11);
            e.target.value = Utils.formatCPF(value);
        });
        
        const telefoneInput = document.getElementById('telefone');
        telefoneInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 11) value = value.slice(0, 11);
            e.target.value = Utils.formatPhone(value);
        });
    },
    
    /**
     * Salva os dados do aluno
     * @param {number|null} id - ID do aluno para edição (null para novo aluno)
     */
    saveAluno: function(id) {
        // Obtém os valores do formulário
        const nome = document.getElementById('nome').value;
        const cpf = document.getElementById('cpf').value.replace(/\D/g, '');
        const dataNascimento = document.getElementById('data-nascimento').value;
        const telefone = document.getElementById('telefone').value.replace(/\D/g, '');
        const email = document.getElementById('email').value;
        const endereco = document.getElementById('endereco').value;
        const planoId = document.getElementById('plano').value;
        const status = document.getElementById('status').value;
        const observacoes = document.getElementById('observacoes').value;
        
        // Valida os campos
        if (!nome || !cpf || !dataNascimento || !telefone || !email || !endereco || !planoId || !status) {
            AlertsComponent.error('Preencha todos os campos obrigatórios.');
            return;
        }
        
        // Valida o CPF
        if (!Utils.validateCPF(cpf)) {
            AlertsComponent.error('CPF inválido.');
            return;
        }
        
        // Valida o email
        if (!Utils.validateEmail(email)) {
            AlertsComponent.error('Email inválido.');
            return;
        }
        
        // Cria o objeto aluno
        const aluno = {
            nome,
            cpf,
            dataNascimento,
            telefone,
            email,
            endereco,
            planoId: parseInt(planoId),
            status,
            observacoes,
            dataInscricao: id ? Storage.getItem('alunos', id).dataInscricao : new Date().toISOString().split('T')[0]
        };
        
        // Salva o aluno
        if (id) {
            Storage.updateItem('alunos', id, aluno);
            AlertsComponent.success('Aluno atualizado com sucesso!');
        } else {
            const novoAluno = Storage.addItem('alunos', aluno);
            
            // Se for um novo aluno, cria um pagamento inicial
            const plano = Storage.getItem('planos', planoId);
            if (plano) {
                const dataVencimento = Utils.addDays(new Date(), plano.duracao);
                
                const pagamento = {
                    alunoId: novoAluno.id,
                    planoId: parseInt(planoId),
                    valor: plano.valor,
                    dataPagamento: new Date().toISOString().split('T')[0],
                    dataVencimento: dataVencimento.toISOString().split('T')[0],
                    formaPagamento: 'dinheiro',
                    status: 'pago'
                };
                
                Storage.addItem('pagamentos', pagamento);
            }
            
            AlertsComponent.success('Aluno cadastrado com sucesso!');
        }
        
        // Recarrega os dados
        this.loadAlunosData();
    },
    
    /**
     * Visualiza os detalhes de um aluno
     * @param {number} id - ID do aluno
     */
    viewAluno: function(id) {
        // Obtém o aluno
        const aluno = Storage.getItem('alunos', id);
        if (!aluno) {
            AlertsComponent.error('Aluno não encontrado.');
            return;
        }
        
        // Obtém o plano do aluno
        const plano = Storage.getItem('planos', aluno.planoId);
        
        // Obtém os pagamentos do aluno
        const pagamentos = Storage.getCollection('pagamentos')
            .filter(p => p.alunoId == aluno.id)
            .sort((a, b) => new Date(b.dataPagamento) - new Date(a.dataPagamento));
        
        // Obtém as presenças do aluno
        const presencas = Storage.getCollection('presencas')
            .filter(p => p.alunoId == aluno.id)
            .sort((a, b) => new Date(b.dataEntrada) - new Date(a.dataEntrada));
        
        // Constrói o conteúdo do modal
        let content = `
            <div class="aluno-details">
                <div class="aluno-header">
                    <div class="aluno-avatar">
                        <i class="fas fa-user"></i>
                    </div>
                    <div class="aluno-info">
                        <h3 class="aluno-name">${aluno.nome}</h3>
                        <span class="status ${aluno.status}">
                            ${aluno.status === 'ativo' ? 'Ativo' : 'Inativo'}
                        </span>
                    </div>
                </div>
                
                <div class="aluno-body">
                    <div class="info-group">
                        <div class="info-label">CPF:</div>
                        <div class="info-value">${Utils.formatCPF(aluno.cpf)}</div>
                    </div>
                    <div class="info-group">
                        <div class="info-label">Data de Nascimento:</div>
                        <div class="info-value">${Utils.formatDate(aluno.dataNascimento)}</div>
                    </div>
                    <div class="info-group">
                        <div class="info-label">Telefone:</div>
                        <div class="info-value">${Utils.formatPhone(aluno.telefone)}</div>
                    </div>
                    <div class="info-group">
                        <div class="info-label">Email:</div>
                        <div class="info-value">${aluno.email}</div>
                    </div>
                    <div class="info-group">
                        <div class="info-label">Endereço:</div>
                        <div class="info-value">${aluno.endereco}</div>
                    </div>
                    <div class="info-group">
                        <div class="info-label">Data de Inscrição:</div>
                        <div class="info-value">${Utils.formatDate(aluno.dataInscricao)}</div>
                    </div>
                    <div class="info-group">
                        <div class="info-label">Plano:</div>
                        <div class="info-value">${plano ? plano.nome : 'N/A'}</div>
                    </div>
                    <div class="info-group">
                        <div class="info-label">Observações:</div>
                        <div class="info-value">${aluno.observacoes || 'Nenhuma observação'}</div>
                    </div>
                </div>
                
                <div class="tabs">
                    <div class="tab-item active" data-tab="pagamentos">Pagamentos</div>
                    <div class="tab-item" data-tab="presencas">Presenças</div>
                </div>
                
                <div class="tab-content active" id="pagamentos-tab">
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Plano</th>
                                    <th>Valor</th>
                                    <th>Vencimento</th>
                                    <th>Forma de Pagamento</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
        `;
        
        if (pagamentos.length === 0) {
            content += `
                <tr>
                    <td colspan="6" class="text-center">Nenhum pagamento registrado.</td>
                </tr>
            `;
        } else {
            pagamentos.forEach(pagamento => {
                const planoPagamento = Storage.getItem('planos', pagamento.planoId);
                content += `
                    <tr>
                        <td>${Utils.formatDate(pagamento.dataPagamento)}</td>
                        <td>${planoPagamento ? planoPagamento.nome : 'N/A'}</td>
                        <td>${Utils.formatCurrency(pagamento.valor)}</td>
                        <td>${Utils.formatDate(pagamento.dataVencimento)}</td>
                        <td>${pagamento.formaPagamento}</td>
                        <td>
                            <span class="status ${pagamento.status === 'pago' ? 'ativo' : 'inativo'}">
                                ${pagamento.status === 'pago' ? 'Pago' : 'Pendente'}
                            </span>
                        </td>
                    </tr>
                `;
            });
        }
        
        content += `
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <div class="tab-content" id="presencas-tab">
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Entrada</th>
                                    <th>Saída</th>
                                    <th>Duração</th>
                                </tr>
                            </thead>
                            <tbody>
        `;
        
        if (presencas.length === 0) {
            content += `
                <tr>
                    <td colspan="4" class="text-center">Nenhuma presença registrada.</td>
                </tr>
            `;
        } else {
            presencas.forEach(presenca => {
                const entrada = new Date(presenca.dataEntrada);
                const saida = presenca.dataSaida ? new Date(presenca.dataSaida) : null;
                
                let duracao = 'Em andamento';
                if (saida) {
                    const diff = Math.abs(saida - entrada);
                    const minutes = Math.floor(diff / 60000);
                    const hours = Math.floor(minutes / 60);
                    const mins = minutes % 60;
                    duracao = `${hours}h ${mins}min`;
                }
                
                content += `
                    <tr>
                        <td>${Utils.formatDate(entrada)}</td>
                        <td>${entrada.getHours().toString().padStart(2, '0')}:${entrada.getMinutes().toString().padStart(2, '0')}</td>
                        <td>${saida ? `${saida.getHours().toString().padStart(2, '0')}:${saida.getMinutes().toString().padStart(2, '0')}` : '-'}</td>
                        <td>${duracao}</td>
                    </tr>
                `;
            });
        }
        
        content += `
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
        
        // Abre o modal
        ModalComponent.open({
            title: 'Detalhes do Aluno',
            content: content,
            confirmText: 'Fechar',
            showCancel: false
        });
        
        // Adiciona listeners para as tabs
        document.querySelectorAll('.tab-item').forEach(tab => {
            tab.addEventListener('click', () => {
                // Remove a classe active de todas as tabs
                document.querySelectorAll('.tab-item').forEach(t => {
                    t.classList.remove('active');
                });
                
                // Adiciona a classe active à tab clicada
                tab.classList.add('active');
                
                // Esconde todos os conteúdos de tab
                document.querySelectorAll('.tab-content').forEach(c => {
                    c.classList.remove('active');
                });
                
                // Mostra o conteúdo da tab clicada
                const tabId = tab.getAttribute('data-tab');
                document.getElementById(`${tabId}-tab`).classList.add('active');
            });
        });
        
        // Adiciona estilos específicos para os detalhes do aluno
        this.addAlunoDetailsStyles();
    },
    
    /**
     * Edita um aluno
     * @param {number} id - ID do aluno
     */
    editAluno: function(id) {
        // Obtém o aluno
        const aluno = Storage.getItem('alunos', id);
        if (!aluno) {
            AlertsComponent.error('Aluno não encontrado.');
            return;
        }
        
        // Mostra o formulário de edição
        this.showAlunoForm(aluno);
    },
    
    /**
     * Exclui um aluno
     * @param {number} id - ID do aluno
     */
    deleteAluno: function(id) {
        // Confirma a exclusão
        ModalComponent.confirm(
            'Tem certeza que deseja excluir este aluno? Esta ação não pode ser desfeita.',
            () => {
                // Exclui o aluno
                Storage.removeItem('alunos', id);
                
                // Exclui os pagamentos do aluno
                const pagamentos = Storage.getCollection('pagamentos');
                pagamentos.filter(p => p.alunoId == id).forEach(p => {
                    Storage.removeItem('pagamentos', p.id);
                });
                
                // Exclui as presenças do aluno
                const presencas = Storage.getCollection('presencas');
                presencas.filter(p => p.alunoId == id).forEach(p => {
                    Storage.removeItem('presencas', p.id);
                });
                
                // Recarrega os dados
                this.loadAlunosData();
                
                // Mostra mensagem de sucesso
                AlertsComponent.success('Aluno excluído com sucesso!');
            },
            'Confirmar Exclusão'
        );
    },
    
    /**
     * Adiciona estilos específicos para os detalhes do aluno
     */
    addAlunoDetailsStyles: function() {
        // Verifica se o estilo já existe
        if (document.getElementById('aluno-details-styles')) return;
        
        // Cria o elemento de estilo
        const style = document.createElement('style');
        style.id = 'aluno-details-styles';
        
        // Define os estilos
        style.textContent = `
            .aluno-details {
                display: flex;
                flex-direction: column;
                gap: 1.5rem;
            }
            
            .aluno-header {
                display: flex;
                align-items: center;
                gap: 1rem;
            }
            
            .aluno-avatar {
                width: 60px;
                height: 60px;
                border-radius: 50%;
                background-color: var(--light-gray);
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 2rem;
                color: var(--dark-gray);
            }
            
            .aluno-info {
                flex: 1;
            }
            
            .aluno-name {
                margin: 0 0 0.5rem 0;
                font-size: 1.25rem;
            }
            
            .aluno-body {
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
                gap: 1rem;
            }
            
            .info-group {
                margin-bottom: 0.5rem;
            }
            
            .info-label {
                font-weight: 500;
                color: var(--dark-gray);
                font-size: 0.9rem;
            }
            
            .info-value {
                font-size: 1rem;
            }
        `;
        
        // Adiciona ao head
        document.head.appendChild(style);
    }
};
