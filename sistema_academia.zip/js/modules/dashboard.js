/**
 * Módulo de Dashboard para o Sistema de Gerenciamento de Academia
 */

const DashboardModule = {
    /**
     * Inicializa o módulo de dashboard
     */
    init: function() {
        console.log('Inicializando módulo de Dashboard...');
        
        // Obtém o container do dashboard
        const container = document.getElementById('dashboard-container');
        
        // Carrega o conteúdo do dashboard
        this.loadDashboard(container);
        
        console.log('Módulo de Dashboard inicializado com sucesso!');
    },
    
    /**
     * Carrega o conteúdo do dashboard
     * @param {HTMLElement} container - Container do dashboard
     */
    loadDashboard: function(container) {
        // Dados para o dashboard
        const totalAlunos = Storage.getCollection('alunos').filter(a => a.status === 'ativo').length;
        const totalInativos = Storage.getCollection('alunos').filter(a => a.status === 'inativo').length;
        
        // Calcula receita do mês atual
        const hoje = new Date();
        const inicioMes = new Date(hoje.getFullYear(), hoje.getMonth(), 1);
        const pagamentosMes = Storage.getCollection('pagamentos').filter(p => {
            const dataPagamento = new Date(p.dataPagamento);
            return dataPagamento >= inicioMes && dataPagamento <= hoje;
        });
        const receitaMes = pagamentosMes.reduce((total, p) => total + p.valor, 0);
        
        // Calcula pagamentos em atraso
        const pagamentosAtraso = Storage.getCollection('pagamentos').filter(p => {
            return p.status === 'pendente' && Utils.isDateInPast(p.dataVencimento);
        });
        
        // Calcula planos a vencer nos próximos 7 dias
        const planosAVencer = Storage.getCollection('pagamentos').filter(p => {
            if (p.status !== 'pago') return false;
            const dataVencimento = new Date(p.dataVencimento);
            const diasAteVencimento = Utils.daysBetween(hoje, dataVencimento);
            return diasAteVencimento >= 0 && diasAteVencimento <= 7;
        });
        
        // Constrói o HTML do dashboard
        container.innerHTML = `
            <div class="dashboard">
                <!-- Cards de resumo -->
                <div class="dashboard-cards">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Alunos Ativos</h3>
                            <div class="card-icon primary">
                                <i class="fas fa-users"></i>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="card-value">${totalAlunos}</div>
                            <div class="card-label">Total de alunos ativos</div>
                        </div>
                        <div class="card-footer">
                            <i class="fas fa-user-plus"></i>
                            <span>Clique para gerenciar alunos</span>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Receita Mensal</h3>
                            <div class="card-icon success">
                                <i class="fas fa-money-bill-wave"></i>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="card-value">${Utils.formatCurrency(receitaMes)}</div>
                            <div class="card-label">Total do mês atual</div>
                        </div>
                        <div class="card-footer positive">
                            <i class="fas fa-chart-line"></i>
                            <span>Clique para ver relatórios</span>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Pagamentos Atrasados</h3>
                            <div class="card-icon danger">
                                <i class="fas fa-exclamation-triangle"></i>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="card-value">${pagamentosAtraso.length}</div>
                            <div class="card-label">Alunos com pagamento em atraso</div>
                        </div>
                        <div class="card-footer negative">
                            <i class="fas fa-clock"></i>
                            <span>Clique para ver detalhes</span>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Planos a Vencer</h3>
                            <div class="card-icon warning">
                                <i class="fas fa-calendar-alt"></i>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="card-value">${planosAVencer.length}</div>
                            <div class="card-label">Nos próximos 7 dias</div>
                        </div>
                        <div class="card-footer">
                            <i class="fas fa-bell"></i>
                            <span>Clique para ver detalhes</span>
                        </div>
                    </div>
                </div>
                
                <!-- Seção de alertas -->
                <div class="dashboard-section">
                    <div class="section-header">
                        <h3 class="section-title">Alertas e Notificações</h3>
                    </div>
                    <div class="section-body">
                        ${this.renderAlerts(pagamentosAtraso, planosAVencer)}
                    </div>
                </div>
                
                <!-- Acesso rápido -->
                <div class="dashboard-section">
                    <div class="section-header">
                        <h3 class="section-title">Acesso Rápido</h3>
                    </div>
                    <div class="section-body">
                        <div class="quick-access">
                            <a href="#alunos" class="quick-access-item">
                                <i class="fas fa-user-plus"></i>
                                <span>Novo Aluno</span>
                            </a>
                            <a href="#pagamentos" class="quick-access-item">
                                <i class="fas fa-money-check"></i>
                                <span>Registrar Pagamento</span>
                            </a>
                            <a href="#presenca" class="quick-access-item">
                                <i class="fas fa-clipboard-check"></i>
                                <span>Registrar Presença</span>
                            </a>
                            <a href="#relatorios" class="quick-access-item">
                                <i class="fas fa-file-alt"></i>
                                <span>Gerar Relatório</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Adiciona listeners para os cards
        const cards = container.querySelectorAll('.card');
        cards[0].addEventListener('click', () => Router.navigateTo('alunos'));
        cards[1].addEventListener('click', () => Router.navigateTo('relatorios'));
        cards[2].addEventListener('click', () => Router.navigateTo('pagamentos'));
        cards[3].addEventListener('click', () => Router.navigateTo('planos'));
        
        // Adiciona estilos específicos para o dashboard
        this.addDashboardStyles();
    },
    
    /**
     * Renderiza os alertas do dashboard
     * @param {Array} pagamentosAtraso - Lista de pagamentos em atraso
     * @param {Array} planosAVencer - Lista de planos a vencer
     * @returns {string} HTML dos alertas
     */
    renderAlerts: function(pagamentosAtraso, planosAVencer) {
        if (pagamentosAtraso.length === 0 && planosAVencer.length === 0) {
            return `
                <div class="empty-state">
                    <i class="fas fa-check-circle empty-state-icon"></i>
                    <h4 class="empty-state-title">Tudo em ordem!</h4>
                    <p class="empty-state-text">Não há alertas ou notificações pendentes no momento.</p>
                </div>
            `;
        }
        
        let html = '<div class="alerts-list">';
        
        // Alertas de pagamentos em atraso
        pagamentosAtraso.forEach(pagamento => {
            const aluno = Storage.getItem('alunos', pagamento.alunoId);
            if (!aluno) return;
            
            html += `
                <div class="alert-item danger">
                    <div class="alert-icon">
                        <i class="fas fa-exclamation-circle"></i>
                    </div>
                    <div class="alert-content">
                        <div class="alert-title">Pagamento em Atraso</div>
                        <div class="alert-message">
                            ${aluno.nome} está com o pagamento vencido desde ${Utils.formatDate(pagamento.dataVencimento)}.
                        </div>
                    </div>
                    <div class="alert-actions">
                        <button class="btn btn-sm btn-primary">Registrar Pagamento</button>
                    </div>
                </div>
            `;
        });
        
        // Alertas de planos a vencer
        planosAVencer.forEach(pagamento => {
            const aluno = Storage.getItem('alunos', pagamento.alunoId);
            if (!aluno) return;
            
            html += `
                <div class="alert-item warning">
                    <div class="alert-icon">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <div class="alert-content">
                        <div class="alert-title">Plano a Vencer</div>
                        <div class="alert-message">
                            O plano de ${aluno.nome} vence em ${Utils.formatDate(pagamento.dataVencimento)}.
                        </div>
                    </div>
                    <div class="alert-actions">
                        <button class="btn btn-sm btn-primary">Renovar Plano</button>
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
        return html;
    },
    
    /**
     * Adiciona estilos específicos para o dashboard
     */
    addDashboardStyles: function() {
        // Verifica se o estilo já existe
        if (document.getElementById('dashboard-styles')) return;
        
        // Cria o elemento de estilo
        const style = document.createElement('style');
        style.id = 'dashboard-styles';
        
        // Define os estilos
        style.textContent = `
            .dashboard {
                display: flex;
                flex-direction: column;
                gap: 1.5rem;
            }
            
            .dashboard-cards {
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
                gap: 1.5rem;
            }
            
            .dashboard-section {
                background-color: var(--white);
                border-radius: 8px;
                box-shadow: var(--shadow-sm);
                overflow: hidden;
            }
            
            .section-header {
                padding: 1rem 1.5rem;
                border-bottom: 1px solid var(--medium-gray);
            }
            
            .section-title {
                margin: 0;
                font-size: 1.1rem;
            }
            
            .section-body {
                padding: 1.5rem;
            }
            
            .alerts-list {
                display: flex;
                flex-direction: column;
                gap: 1rem;
            }
            
            .alert-item {
                display: flex;
                align-items: center;
                padding: 1rem;
                border-radius: 8px;
                gap: 1rem;
            }
            
            .alert-item.danger {
                background-color: rgba(231, 76, 60, 0.1);
            }
            
            .alert-item.warning {
                background-color: rgba(243, 156, 18, 0.1);
            }
            
            .alert-icon {
                font-size: 1.5rem;
            }
            
            .alert-item.danger .alert-icon {
                color: var(--accent-color);
            }
            
            .alert-item.warning .alert-icon {
                color: #f39c12;
            }
            
            .alert-content {
                flex: 1;
            }
            
            .alert-title {
                font-weight: 600;
                margin-bottom: 0.25rem;
            }
            
            .alert-message {
                font-size: 0.9rem;
                color: var(--text-dark);
            }
            
            .alert-actions {
                display: flex;
                gap: 0.5rem;
            }
            
            .btn-sm {
                padding: 0.25rem 0.5rem;
                font-size: 0.8rem;
            }
            
            .quick-access {
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
                gap: 1rem;
            }
            
            .quick-access-item {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                padding: 1.5rem;
                background-color: var(--light-gray);
                border-radius: 8px;
                text-align: center;
                color: var(--text-dark);
                transition: transform var(--transition-speed), background-color var(--transition-speed);
            }
            
            .quick-access-item:hover {
                transform: translateY(-5px);
                background-color: var(--primary-color);
                color: var(--white);
            }
            
            .quick-access-item i {
                font-size: 2rem;
                margin-bottom: 0.75rem;
            }
            
            @media (max-width: 768px) {
                .dashboard-cards {
                    grid-template-columns: 1fr;
                }
                
                .quick-access {
                    grid-template-columns: repeat(2, 1fr);
                }
            }
        `;
        
        // Adiciona ao head
        document.head.appendChild(style);
    }
};
