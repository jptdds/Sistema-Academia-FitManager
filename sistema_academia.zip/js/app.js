/**
 * Aplicação principal do Sistema de Gerenciamento de Academia
 */

// Objeto principal da aplicação
const App = {
    /**
     * Inicializa a aplicação
     */
    init: function() {
        console.log('Inicializando Sistema de Gerenciamento de Academia...');
        
        // Inicializa o armazenamento
        Storage.init();
        
        // Inicializa o sistema de autenticação
        Auth.init();
        
        // Inicializa o sistema de roteamento
        Router.init();
        
        // Inicializa os componentes da interface
        this.initComponents();
        
        // Adiciona listeners para eventos globais
        this.addEventListeners();
        
        console.log('Sistema inicializado com sucesso!');
    },
    
    /**
     * Inicializa os componentes da interface
     */
    initComponents: function() {
        // Inicializa a sidebar
        SidebarComponent.init();
        
        // Inicializa o sistema de modais
        ModalComponent.init();
        
        // Inicializa o sistema de alertas
        AlertsComponent.init();
    },
    
    /**
     * Adiciona listeners para eventos globais
     */
    addEventListeners: function() {
        // Listener para o botão de logout
        document.getElementById('logout-btn').addEventListener('click', () => {
            Auth.logout();
            Router.showLoginPage();
        });
    }
};

// Inicializa a aplicação quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', () => {
    App.init();
});
