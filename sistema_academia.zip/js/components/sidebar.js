/**
 * Componente de Sidebar para o Sistema de Gerenciamento de Academia
 */

const SidebarComponent = {
    /**
     * Inicializa o componente de sidebar
     */
    init: function() {
        // Adiciona listener para o botão de toggle da sidebar
        document.getElementById('sidebar-toggle').addEventListener('click', () => {
            this.toggleSidebar();
        });
        
        // Em dispositivos móveis, inicia com a sidebar colapsada
        if (window.innerWidth <= 768) {
            this.collapseSidebar();
        }
        
        // Adiciona listener para redimensionamento da janela
        window.addEventListener('resize', () => {
            if (window.innerWidth <= 768) {
                this.collapseSidebar();
            } else {
                this.expandSidebar();
            }
        });
    },
    
    /**
     * Alterna o estado da sidebar (expandida/colapsada)
     */
    toggleSidebar: function() {
        const sidebar = document.getElementById('sidebar');
        sidebar.classList.toggle('collapsed');
    },
    
    /**
     * Colapsa a sidebar
     */
    collapseSidebar: function() {
        const sidebar = document.getElementById('sidebar');
        sidebar.classList.add('collapsed');
    },
    
    /**
     * Expande a sidebar
     */
    expandSidebar: function() {
        const sidebar = document.getElementById('sidebar');
        sidebar.classList.remove('collapsed');
    }
};
