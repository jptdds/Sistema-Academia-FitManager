/**
 * Componente de Modal para o Sistema de Gerenciamento de Academia
 */

const ModalComponent = {
    /**
     * Inicializa o componente de modal
     */
    init: function() {
        // Referência ao elemento modal
        this.modal = document.getElementById('modal');
        
        // Adiciona listener para o botão de fechar
        const closeButton = this.modal.querySelector('.modal-close');
        closeButton.addEventListener('click', () => {
            this.close();
        });
        
        // Adiciona listener para o botão de cancelar
        const cancelButton = this.modal.querySelector('.modal-cancel');
        cancelButton.addEventListener('click', () => {
            this.close();
        });
        
        // Fecha o modal ao clicar fora dele
        this.modal.addEventListener('click', (e) => {
            if (e.target === this.modal) {
                this.close();
            }
        });
    },
    
    /**
     * Abre o modal com conteúdo personalizado
     * @param {Object} options - Opções do modal
     * @param {string} options.title - Título do modal
     * @param {string} options.content - Conteúdo HTML do modal
     * @param {Function} options.onConfirm - Função a ser executada ao confirmar
     * @param {string} options.confirmText - Texto do botão de confirmação
     * @param {string} options.cancelText - Texto do botão de cancelamento
     * @param {boolean} options.showCancel - Se deve mostrar o botão de cancelar
     */
    open: function(options) {
        // Define valores padrão
        const defaults = {
            title: 'Modal',
            content: '',
            onConfirm: null,
            confirmText: 'Confirmar',
            cancelText: 'Cancelar',
            showCancel: true
        };
        
        // Mescla as opções com os valores padrão
        const settings = { ...defaults, ...options };
        
        // Define o título
        this.modal.querySelector('.modal-title').textContent = settings.title;
        
        // Define o conteúdo
        this.modal.querySelector('.modal-body').innerHTML = settings.content;
        
        // Configura o botão de confirmação
        const confirmButton = this.modal.querySelector('.modal-confirm');
        confirmButton.textContent = settings.confirmText;
        
        // Remove listeners anteriores
        const newConfirmButton = confirmButton.cloneNode(true);
        confirmButton.parentNode.replaceChild(newConfirmButton, confirmButton);
        
        // Adiciona novo listener
        if (settings.onConfirm) {
            newConfirmButton.addEventListener('click', () => {
                settings.onConfirm();
                this.close();
            });
        } else {
            newConfirmButton.addEventListener('click', () => {
                this.close();
            });
        }
        
        // Configura o botão de cancelamento
        const cancelButton = this.modal.querySelector('.modal-cancel');
        cancelButton.textContent = settings.cancelText;
        
        // Mostra ou esconde o botão de cancelar
        if (settings.showCancel) {
            cancelButton.style.display = 'block';
        } else {
            cancelButton.style.display = 'none';
        }
        
        // Abre o modal
        this.modal.classList.add('active');
    },
    
    /**
     * Fecha o modal
     */
    close: function() {
        this.modal.classList.remove('active');
    },
    
    /**
     * Abre um modal de confirmação
     * @param {string} message - Mensagem de confirmação
     * @param {Function} onConfirm - Função a ser executada ao confirmar
     * @param {string} title - Título do modal
     */
    confirm: function(message, onConfirm, title = 'Confirmação') {
        this.open({
            title: title,
            content: `<p>${message}</p>`,
            onConfirm: onConfirm,
            confirmText: 'Confirmar',
            cancelText: 'Cancelar',
            showCancel: true
        });
    },
    
    /**
     * Abre um modal de alerta
     * @param {string} message - Mensagem de alerta
     * @param {string} title - Título do modal
     */
    alert: function(message, title = 'Alerta') {
        this.open({
            title: title,
            content: `<p>${message}</p>`,
            confirmText: 'OK',
            showCancel: false
        });
    }
};
