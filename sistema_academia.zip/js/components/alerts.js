/**
 * Componente de Alertas para o Sistema de Gerenciamento de Academia
 */

const AlertsComponent = {
    /**
     * Inicializa o componente de alertas
     */
    init: function() {
        // Referência ao container de notificações
        this.container = document.getElementById('notification-container');
    },
    
    /**
     * Mostra uma notificação
     * @param {string} message - Mensagem da notificação
     * @param {string} type - Tipo da notificação (success, error, info)
     * @param {number} duration - Duração em ms (0 para não fechar automaticamente)
     */
    show: function(message, type = 'info', duration = 3000) {
        // Cria o elemento de notificação
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        
        // Define o ícone com base no tipo
        let icon = 'info-circle';
        if (type === 'success') icon = 'check-circle';
        if (type === 'error') icon = 'exclamation-circle';
        
        // Define o conteúdo da notificação
        notification.innerHTML = `
            <i class="fas fa-${icon} notification-icon"></i>
            <div class="notification-message">${message}</div>
            <button class="notification-close">&times;</button>
        `;
        
        // Adiciona ao container
        this.container.appendChild(notification);
        
        // Adiciona listener para o botão de fechar
        const closeButton = notification.querySelector('.notification-close');
        closeButton.addEventListener('click', () => {
            this.close(notification);
        });
        
        // Fecha automaticamente após a duração especificada
        if (duration > 0) {
            setTimeout(() => {
                this.close(notification);
            }, duration);
        }
    },
    
    /**
     * Fecha uma notificação
     * @param {HTMLElement} notification - Elemento da notificação
     */
    close: function(notification) {
        // Adiciona animação de saída
        notification.style.animation = 'slideOut 0.3s ease-out forwards';
        
        // Remove após a animação
        setTimeout(() => {
            notification.remove();
        }, 300);
    },
    
    /**
     * Mostra uma notificação de sucesso
     * @param {string} message - Mensagem da notificação
     * @param {number} duration - Duração em ms
     */
    success: function(message, duration = 3000) {
        this.show(message, 'success', duration);
    },
    
    /**
     * Mostra uma notificação de erro
     * @param {string} message - Mensagem da notificação
     * @param {number} duration - Duração em ms
     */
    error: function(message, duration = 3000) {
        this.show(message, 'error', duration);
    },
    
    /**
     * Mostra uma notificação de informação
     * @param {string} message - Mensagem da notificação
     * @param {number} duration - Duração em ms
     */
    info: function(message, duration = 3000) {
        this.show(message, 'info', duration);
    }
};
