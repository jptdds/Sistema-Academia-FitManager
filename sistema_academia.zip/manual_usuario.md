# Manual do Usuário - Sistema de Gerenciamento para Academia

## Introdução

Bem-vindo ao **FitManager**, um sistema completo de gerenciamento para academias desenvolvido com HTML, CSS e JavaScript. Este sistema foi projetado para facilitar o controle de alunos, planos, pagamentos e presença, oferecendo uma interface intuitiva e responsiva.

## Requisitos do Sistema

O FitManager é uma aplicação web que pode ser executada em qualquer navegador moderno:
- Google Chrome (recomendado)
- Mozilla Firefox
- Microsoft Edge
- Safari

## Acesso ao Sistema

Para acessar o sistema, abra o arquivo `index.html` em seu navegador. Na tela de login, utilize as seguintes credenciais:

- **Email**: admin@academia.com
- **Senha**: admin123

## Visão Geral das Funcionalidades

### Dashboard

O Dashboard é a tela inicial do sistema, apresentando um resumo das informações mais importantes:

- **Alunos Ativos**: Total de alunos com status ativo no sistema
- **Receita Mensal**: Valor total de pagamentos recebidos no mês atual
- **Pagamentos Atrasados**: Número de alunos com pagamentos em atraso
- **Planos a Vencer**: Planos que vencem nos próximos 7 dias

Além disso, o Dashboard exibe alertas e notificações importantes, como pagamentos em atraso e planos próximos ao vencimento.

### Gestão de Alunos

Neste módulo, você pode:

1. **Cadastrar novos alunos**:
   - Clique no botão "Novo Aluno"
   - Preencha os dados pessoais (nome, CPF, data de nascimento, etc.)
   - Selecione um plano
   - Defina o status (ativo/inativo)
   - Clique em "Salvar"

2. **Visualizar alunos**:
   - A lista de alunos é exibida em formato de tabela
   - Utilize os filtros para buscar por nome, status ou plano
   - Clique no ícone de olho para ver detalhes completos do aluno

3. **Editar alunos**:
   - Clique no ícone de lápis na linha do aluno
   - Atualize os dados necessários
   - Clique em "Salvar"

4. **Excluir alunos**:
   - Clique no ícone de lixeira na linha do aluno
   - Confirme a exclusão

### Gestão de Planos

Este módulo permite gerenciar os planos oferecidos pela academia:

1. **Cadastrar novos planos**:
   - Clique no botão "Novo Plano"
   - Defina nome, valor e duração (em dias)
   - Clique em "Salvar"

2. **Editar planos existentes**:
   - Clique no ícone de lápis na linha do plano
   - Atualize os dados necessários
   - Clique em "Salvar"

3. **Excluir planos**:
   - Clique no ícone de lixeira na linha do plano
   - Confirme a exclusão

### Controle de Pagamentos

Neste módulo, você pode:

1. **Registrar novos pagamentos**:
   - Clique no botão "Novo Pagamento"
   - Selecione o aluno
   - Selecione o plano
   - Defina valor, data de pagamento e vencimento
   - Selecione a forma de pagamento
   - Clique em "Salvar"

2. **Visualizar histórico de pagamentos**:
   - A lista de pagamentos é exibida em formato de tabela
   - Utilize os filtros para buscar por aluno, status ou período

3. **Gerar comprovantes**:
   - Clique no ícone de impressora na linha do pagamento
   - O comprovante será aberto em uma nova janela, pronto para impressão

### Controle de Presença

Este módulo permite registrar a entrada e saída dos alunos:

1. **Registrar entrada**:
   - Clique no botão "Registrar Entrada"
   - Selecione o aluno
   - A data e hora atual serão registradas automaticamente
   - Clique em "Confirmar"

2. **Registrar saída**:
   - Localize o aluno na lista de presenças ativas
   - Clique no botão "Registrar Saída"
   - A data e hora atual serão registradas automaticamente

3. **Visualizar histórico de presença**:
   - Utilize os filtros para buscar por aluno ou período
   - Visualize a duração de cada sessão

### Relatórios

O módulo de relatórios oferece insights importantes sobre o negócio:

1. **Relatório de Receitas**:
   - Visualize a receita por período (diária, semanal, mensal, anual)
   - Compare com períodos anteriores

2. **Relatório de Alunos**:
   - Analise a evolução do número de alunos
   - Visualize a distribuição por planos

3. **Relatório de Frequência**:
   - Identifique os horários de maior movimento
   - Analise a assiduidade dos alunos

4. **Exportar Relatórios**:
   - Clique no botão "Exportar" para salvar o relatório em formato CSV

## Armazenamento de Dados

O FitManager utiliza o localStorage do navegador para armazenar os dados. Isso significa que:

1. Os dados são armazenados apenas no navegador onde o sistema é acessado
2. Não há sincronização automática entre diferentes dispositivos
3. Limpar o cache do navegador pode resultar na perda dos dados

Para preservar seus dados, utilize regularmente a função de exportação disponível no sistema.

## Dicas e Boas Práticas

1. **Backup regular**: Exporte os dados periodicamente para evitar perdas
2. **Manutenção de cadastros**: Mantenha os dados dos alunos sempre atualizados
3. **Registro de pagamentos**: Registre os pagamentos assim que forem realizados
4. **Controle de presença**: Incentive os alunos a sempre registrarem entrada e saída

## Solução de Problemas

### O sistema não carrega corretamente

- Verifique se está utilizando um navegador atualizado
- Tente limpar o cache do navegador e recarregar a página
- Verifique se o JavaScript está habilitado no navegador

### Dados não estão sendo salvos

- Verifique se o localStorage está habilitado no navegador
- Certifique-se de que há espaço disponível no armazenamento local

### Erro ao fazer login

- Verifique se está utilizando as credenciais corretas
- Tente limpar o cache do navegador e tentar novamente

## Considerações Finais

O FitManager foi desenvolvido para simplificar a gestão da sua academia, oferecendo ferramentas intuitivas para controle de alunos, pagamentos e presença. Esperamos que este sistema contribua para o sucesso do seu negócio!

Para suporte adicional ou sugestões de melhorias, entre em contato conosco.

---

© 2025 FitManager - Todos os direitos reservados
